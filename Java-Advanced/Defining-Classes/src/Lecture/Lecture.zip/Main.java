package Lecture;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = Integer.parseInt(sc.nextLine());
        List<Car> cars = new ArrayList<>();

        while(n-- > 0){
            String[] currentCarInfo = sc.nextLine().split("\\s+");
            Car currentCar;
            if(currentCarInfo.length == 1){
                currentCar = new Car(currentCarInfo[0]);
            }else{
                currentCar = new Car(currentCarInfo[0], currentCarInfo[1], Integer.parseInt(currentCarInfo[2]));
            }
            cars.add(currentCar);

        }

        cars.forEach(car -> System.out.printf("The car is: %s %s - %d HP.%n"
                            , car.getBrand(),car.getModel(),car.getHorsePower()));

    }
}
